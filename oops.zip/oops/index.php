<?php 
require_once("includes/config.php");
// Class Init
$cities = new cities;
$users = new users;

if(isset($_POST['save']))
{

	$errors = array();
	$errors = $users->validate_add();
	if(!count($errors))
	{
		if($_FILES['avatar']['error']==0)
		{
			$src = $_FILES['avatar']['tmp_name'];
			$dest = FTP_AVATAR_DIR.$_FILES['avatar']['name'];
			if(move_uploaded_file($src,$dest))
			{
				$_POST['avatar'] = $_FILES['avatar']['name'];
			}
			$_POST['hobbies'] = implode(", ",$_POST['hobbies']); 
			$_POST['password'] = md5($_POST['password']);
			$_POST['created'] = date("Y-m-d h:m:s");
			//print_r($_POST);exit;
			
			if($users->save($users->table,$_POST))
			{
				echo "Save";
			}
			else
			{
				echo "Fail";
			}
		}
	}
}




//Fetch cities Query
$selectcities = $cities->select($cities->table,'','','name');




?>

<html>
	<head>
		<title>Form</title>
		<style>
			.mylabels
			{
				vertical-align:top;
				width:150px;
			}
			.errors
			{
				margin:2px 0px;
				background-color:red;
				color:#fff;
				padding:3px;
			}
		</style>
		<script src="js/jquery.min.js"></script>
		<script src="ckeditor/ckeditor.js"></script>
		<link rel="stylesheet" href="ckeditor/samples/old/sample.css">
		<script>
			$(document).ready( function() {
				CKEDITOR.replace( 'editor1',{});
			} );
		</script>
	</head>
	<body>
		<form method="post" enctype="multipart/form-data">
		<table cellpadding="10px" cellspacing="0px" width="100%" align="center" border="1">
			<tr>
				<td class="mylabels"><label>Name :</label></td>
				<td><input type="text" name="name"/>
				<?php if(isset($errors['name'])){?>
				<div class="errors"><?php echo $errors['name']; ?></div>
				<?php } ?>
				</td>
			</tr>
			<tr>
				<td class="mylabels"><label>Password :</label></td>
				<td><input type="password" name="password" />
				<?php if(isset($errors['password'])){?>
				<div class="errors"><?php echo $errors['password']; ?></div>
				<?php } ?>
				
				</td>
			</tr>
			<tr>
				<td class="mylabels"><label>Address :</label></td>
				<td><textarea rows="5" col="30" name="address"></textarea>
				<?php if(isset($errors['address'])){?>
				<div class="errors"><?php echo $errors['address']; ?></div>
				<?php } ?>
				</td>
			</tr>
			<tr>
				<td class="mylabels"><label>Gender :</label></td>
				<td>
					<input type="radio" name="gender" value="male"/>Male
					<input type="radio" name="gender" value="female"/>Female
				</td>
			</tr>
			<tr>
				<td class="mylabels"><label>Hobbies :</label></td>
				<td>
					<input type="checkbox" name="hobbies[]" value="reading"/>Reading
					<input type="checkbox" name="hobbies[]" value="singing"/>Singing
				</td>
			</tr>
			<tr>
				<td class="mylabels"><label>City :</label></td>
				<td>
					<select name="city_id">
						<option value="0">-- Select City --</option>
						<?php foreach($selectcities as $selectcity){?>
						<option value="<?php echo $selectcity['id'];?>"><?php echo $selectcity['name'];?></option>
						<?php } ?>
					</select>
				</td>
			</tr>
			<tr>
				<td class="mylabels"><label>Avatar :</label></td>
				<td><input type="file" name="avatar"/></td>
			</tr>
			<tr>
				<td class="mylabels"><label>Description :</label></td>
				<td><textarea id="editor1" name="description"></textarea></td>
			</tr>
			<tr>
				<td class="mylabels"><label>&nbsp;</label></td>
				<td>
					<input type="submit" name="save" value="Save"/>
					<input type="reset" name="reset" value="Reset"/>
					<input type="button" name="show" value="Display Details" onclick="window.location='show.php'"/>
				</td>
			</tr>
		</table>
		</form>
		
	</body>
</html>