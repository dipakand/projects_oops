<?php   
// Set Path for HTTP & FTP
define('HTTP_DOMAIN','http://localhost/trainings/batch_22_010116/PHP/oops/');
define('FTP_DOMAIN', 'D:/xampp/htdocs/trainings/batch_22_010116/PHP/oops/');

// Set Path for  Images OR Avatar with ref of HTTP & FTP
define('HTTP_AVATAR_DIR', HTTP_DOMAIN.'images/avatar/');
define('FTP_AVATAR_DIR', FTP_DOMAIN.'images/avatar/');

// Call Master File
require_once('models/db.php');

// Call Run time class entity
require_once('includes/database.php');

// Manage Session Details
session_start();
session_name('Auth');

?>
