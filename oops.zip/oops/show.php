<?php 
require_once("includes/config.php");
$users = new users;
$cities = new cities;
require_once("includes/pagination.php");
if(isset($_POST['deleteall']))
{
	$id=$_POST['selector'];
	$no=count($id);
	for($s=0;$s<$no;$s++)
	{
		
		if($users->delete($users->table,"id=$id[$s]"))
		{
			// call unlink Functionality if attachment available
 		}
		
	}
}
if(isset($_POST['search']))
{
	$cond = "name like '".$_POST['s']."%'";
	$allusers = $users->select($users->table,'',$cond,'name',$limit); 
}
else
{
$allusers = $users->select($users->table,'','','name',$limit);
}
?>

<html>
	<head>
		<title>Form</title>
		<style>
			.mylabels
			{
				vertical-align:top;
				width:150px;
			}
			.errors
			{
				margin:2px 0px;
				background-color:red;
				color:#fff;
				padding:3px;
			}
			#current
			{
				background-color:red;
				color:#fff;
				padding:5px;
			}
		</style>
		
	</head>
	<body>
		<form method="post">
		<table cellpadding="10px" cellspacing="0px" width="100%" align="center" border="1">
			<tr>
				<td>
					Search By Name : <input type="text" name='s'/> <input type="submit" name='search' value="Search"/> 
				</td>
			</tr>
		</table>
		</form>
		<form method="post">
		<table cellpadding="10px" cellspacing="0px" width="100%" align="center" border="1">
		<tr>
			<th></th>
			<th>Sr</th>
			<th>Name</th>
			<th>Address</th>
			<th>Gender</th>
			<th>City</th>
			<th>Avatar</th>
			<th>Action</th>
		</tr>
		<?php foreach($allusers as $alluser){?>
		<tr>
			<td><input type="checkbox" name="selector[]" value="<?php echo $alluser['id'];?>"/></td>
			<td><?php echo $alluser['id'];?></td>
			<td><?php echo $alluser['name'];?></td>
			<td><?php echo $alluser['address'];?></td>
			<td><?php echo $alluser['gender'];?></td>
			<td><?php 
			$c = $cities->select($cities->table,'','id='.$alluser['city_id']);
			
			echo $c[0]['name'];?></td>
			<td><img src="<?php echo HTTP_AVATAR_DIR.$alluser['avatar'];?>" alt="" width="30px"/></td>
			<td>Show | Edit | Delete</td>
		</tr>
		<?php } ?>
		<tr>
			<td colspan="8">
				<input type="submit" name="deleteall" value="Delete Selected"/>
			</td>
		</tr>
		<tr>
			<td colspan="8">
			<?php 
				for($i=1;$i<=$totp;$i++)
				{
					if($page == $i)
					{
						echo "<span id='current'>".$i."</span>&nbsp;";
					}
					else
					{
					echo "<a href='".$_SERVER['PHP_SELF']."?page=$i'>".$i."</a> ";
					}
				}
			?>
			</td>
		</tr>
		</table>
		</form>
	</body>
</html>