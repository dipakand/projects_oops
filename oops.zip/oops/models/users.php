<?php 
class users extends DB
{
	// Init of Table
	var $table = "users";
	
	function validate_add()
	{
		$errors = array();
		if(empty($_POST['name']))
		{
			$errors['name'] = "Please Enter Name";
		}
		elseif(!preg_match("#^[-A-Za-z ']*$#",$_POST['name']))
		{
			$errors['name'] = "Please Enter Valid Name";
		}
		
		if(empty($_POST['password']))
		{
			$errors['password'] = "Please Enter Password";
		}
		elseif(strlen($_POST['password'])<8 || strlen($_POST['password'])>16)
		{
			$errors['password'] = "Password should be > 8 or < 16";
			
		}
		if(empty($_POST['address']))
		{
			$errors['address'] = "Please Enter address";
		}
		return $errors;
		
	}
}


?>