<?php 
class cities extends DB
{
	// Table initialisation
	var $table = "cities";
	
	function validate_add()
	{
		
	}
	function validate_edit()
	{
		
	}
}
?>