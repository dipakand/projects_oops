<?php
error_reporting(0);
require_once("includes/config.php");
$users = new users;
if(isset($_GET['data']))
{
	$selectdata = $users->select($users->table,'',"name like '".$_GET['data']."%'");
}
else
{
$selectdata = $users->select($users->table);
}
?>	
		<script src="js/jquery.min.js"></script>
		<script>
			$('document').ready(function(){
				
				$(".textbox").hide();$(".update").hide();$(".edit").click(function(){
					//$(".text").hide();
					//$(".textbox").show();
					
					var ID = $(this).attr("id");
					
					$("#textbox_name_"+ID).show();
					$("#textbox_email_"+ID).show();
					$("#textbox_mobile_"+ID).show();
					
					$("#text_name_"+ID).hide();
					$("#text_email_"+ID).hide();
					$("#text_mobile_"+ID).hide();
					
					
					
					//return false;
					$(".edit").hide();
					$(".update").show();
				});
				$(".update").click(function(){

					var ID = $(this).attr("id");
					var name = $("#textbox_name_"+ID).val();
					var email = $("#textbox_email_"+ID).val();
					var mobile = $("#textbox_mobile_"+ID).val();
										
					
					$("#textbox_name_"+ID).hide();
					$("#textbox_email_"+ID).hide();
					$("#textbox_mobile_"+ID).hide();
					
					$("#text_name_"+ID).show();
					$("#text_email_"+ID).show();
					$("#text_mobile_"+ID).show();
					
					$.ajax({
						type:'post',
						url:'change.php',
						data:'name='+name+'&email='+email+'&mobile='+mobile+'&id='+ID,
						cache:false,
						
						success:function(data)
						{
							$("#text_name_"+ID).text(name);
							$("#text_email_"+ID).text(email);
							$("#text_mobile_"+ID).text(mobile);
						}
						
					}); 
					
					//return false;
					$(".edit").show();
					$(".update").hide();
					
				});
				
				
				$(".delete").click(function(){
					var a = confirm('delete?');
					if(a==true)
					{
					var ID = $(this).attr("id");
					$.ajax({
						type:'post',
						url:'change.php',
						data:"id="+ID,
						cache:false,
						
						success:function(data)
						{
							//alert(data);
							$("#mytr_"+ID).fadeOut("slow");
							
						}
						
					});
					}
					else
					{
						alert("action cancel");
					}
					
				});
			});
		</script>

	<table cellpadding="10px" cellspacing="0px" width="90%" align="center" border="1">
			
			<tr>
				<th>Sr. No</th>
				<th>Name</th>
				<th>Email</th>
				<th>Mobile</th>
				<th>Action</th>
			</tr>
			<?php $sr = 1; foreach($selectdata as $rows){?>
			<tr id="mytr_<?php echo $rows['id'];?>">
				<td>
				
				<?php echo $sr;?></td>
				
				<td>
				<span class="text" id="text_name_<?php echo $rows['id'];?>"><?php echo $rows['name'];?></span>
				
				<input class="textbox" type="text" id="textbox_name_<?php echo $rows['id'];?> "value="<?php echo $rows['name'];?>"/>
				</td>
				<td>
				<span class="text" id="text_email_<?php echo $rows['id'];?>"><?php echo $rows['email'];?></span>
				<input  class="textbox" type="text" id="textbox_email_<?php echo $rows['id'];?>" value="<?php echo $rows['email'];?>"/>
				</td>
				<td>
				<span class="text" id="text_mobile_<?php echo $rows['id'];?>"><?php echo $rows['mobile'];?></span>
				<input  class="textbox" type="text" id="textbox_mobile_<?php echo $rows['id'];?>" value="<?php echo $rows['mobile'];?>"/>
				</td>
				<td>
				
				<a href="#" class="edit" id="<?php echo $rows['id'];?>">Edit</a> 
				<a href="#" class="update" id="<?php echo $rows['id'];?>">Update</a>| 
				
				<a href="#" class="delete" id="<?php echo $rows['id'];?>">Delete</a></td>
			</tr>
			<?php $sr++;} ?>
		</table>