<?php 
$rpp = 10;
if(isset($_GET['page']))
{
	$page = $_GET['page'];
}
else
{
	$page = 1;
}
$rsf = ( $page * $rpp ) - $rpp;
$limit = "$rsf,$rpp";
if(isset($_POST['search']))
{
	$cond = "name like '".$_POST['s']."%'";
	$alluserscount = count($users->select($users->table,'',$cond));	
}
else
{
//Counting Total Records
$alluserscount = count($users->select($users->table));
}
// Total Pages
$totp = ceil($alluserscount/$rpp);
?>