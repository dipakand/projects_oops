<?php 
require_once("includes/config.php");
//print_r($_POST);exit;

if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['mobile']))
{
	$users = new users;
	if($users->select($users->table,'',"mobile='".$_POST['mobile']."'"))
	{
		echo 1;
	}
	else
	{
		$_POST['status']='inactive';
		$_POST['created'] = date("Y-m-d h:m:s");	
		
		if($users->save($users->table,$_POST))
		{
			echo 2;
		}
	}
		
}
else
{
	echo 0;	
}


?>