<?php 
class users extends DB
{
	// Init of Table
	var $table = "users";	
}


?>