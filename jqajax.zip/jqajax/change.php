<?php 
//print_r($_POST);exit;
require_once("includes/config.php");
$users= new users;
if(isset($_POST['name']) && isset($_POST['id']))
{
	$users->save($users->table,$_POST,"id='".$_POST['id']."'");
}
else
{
	
	$users->delete($users->table,"id='".$_POST['id']."'");
}
	
?>