	$('document').ready(function(){
				//alert("hi");
				$("#mytable").hide();
				
				$("#myclick").click(function(){
					$("#myclick").hide();
					$("#myheading").toggle('slow');
					$("#mytable").fadeIn('slow');
					$(".error").hide();
				});
				
				$("#register").click(function(){
					var name = $("#name").val();
					var email = $("#email").val();
					var mobile = $("#mobile").val();
					
					var pattern_name=/^[A-Za-z' ]{1,80}$/i;
					var pattern_email=/^[a-z0-9._-]+@[a-z]+.[a-z.]{2,5}$/i;
					var pattern_mobile=/^[0-9]{1,80}$/i;
					
					//alert(name+" = "+email+" = "+mobile);
					
					
					if(name=='')
					{
						var ename = "Please Enter Name";
						$("#ename").text(ename).fadeIn('slow');
						setTimeout(function(){
							$("#ename").fadeOut('slow');
							
						},3000);
						$("#name").focus();
						return false;
					}
					else if(!pattern_name.test(name))
					{
						var ename = "Please Enter Valid Name";
						$("#ename").text(ename).fadeIn('slow');
						setTimeout(function(){
							$("#ename").fadeOut('slow');
							
						},3000);
						$("#name").focus();
						return false;
					}
					if(email=='')
					{
						var eemail = "Please Enter Email";
						$("#eemail").text(eemail).fadeIn('slow');
						setTimeout(function(){
							$("#eemail").fadeOut('slow');
							
						},3000);
						$("#email").focus();
						return false;
					}
					if(mobile=='')
					{
						var emobile = "Please Enter Mobile";
						$("#emobile").text(emobile).fadeIn('slow');
						setTimeout(function(){
							$("#emobile").fadeOut('slow');
							
						},3000);
						$("#mobile").focus();
						return false;
					}
					else
					{
						$.ajax({
							type:'post',
							url:'add.php',
							data:'name='+name+'&email='+email+'&mobile='+mobile,
							cache:false,
							
							success:function(returndata){
								//alert(returndata);
								if(returndata==1)
								{
									var msg = "Mobile Already Register";
									$("#msg").text(msg).show();
								}
								else
								{
									var msg = "Register Success";
									$("#msg").text(msg).show();
								}
							}
						});
					}
					
					
				});
				
				$("#show").click(function(){
					window.location='show.html';					
				});
				
			});